# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 02:07:28 2022

@author: AbelRamos
"""

def funlist(lista):
     for item in lista:
         print("Hola",item)
     print(" ")
funlist(["Ana"])
funlist(["Ana","Israel"])
funlist(["Ana","Israel","Carlos"])