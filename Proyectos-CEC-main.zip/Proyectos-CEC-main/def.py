# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 00:05:10 2022

@author: AbelRamos
"""

def mensaje():
    print("Ingrese un dato")
    
mensaje()
a=input()
mensaje()
b=input()
mensaje()
c=input()
mensaje()
d=input()
print(a+b+c+d)