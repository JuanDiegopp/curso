# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 02:12:24 2022

@author: AbelRamos
"""

def crealista(n):
    lista=[]
    for item in range(n):
        lista.append(item)
    return lista

print(crealista(10))