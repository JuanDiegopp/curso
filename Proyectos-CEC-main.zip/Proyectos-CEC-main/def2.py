# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 01:31:40 2022

@author: AbelRamos
"""

def fun2 (nombre):
    print("Hola!",nombre)
    
fun2("Ana")
fun2("Juan")
fun2("Carlos")
fun2(4)