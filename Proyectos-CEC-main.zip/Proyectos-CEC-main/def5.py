# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 01:57:19 2022

@author: AbelRamos
"""

def mul(a,b):
    print(a*b)
    return a*b
mul(5, 5)

resultado=mul(15, 65)
opt=resultado+5