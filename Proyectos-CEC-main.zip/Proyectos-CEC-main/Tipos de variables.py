# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 03:42:51 2022

@author: AbelRamos
"""
print(type(8))
print(type("Abel"))
print(type(True))
print(type(8.5))
print("\n"*2)
num_1=8
num_2=3
div=num_1/num_2
print(div)
print("\n"*2)
print(1<1)
print(1<=1)
print("\n"*2)
x=1
y=2
z=x+y
r=10
print(z*5)
print("\n"*2)
print(r*" Cisco Networking Academy ")
