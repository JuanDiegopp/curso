# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 04:10:52 2022

@author: AbelRamos
"""

pi=22/7
print(pi)
print("{:.52f}".format(pi))