# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 03:05:47 2022

@author: AbelRamos
"""

print("¡Hola mundo!")