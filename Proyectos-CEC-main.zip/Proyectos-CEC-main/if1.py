# -*- coding: utf-8 -*-
"""
Created on Sun Mar 20 19:13:37 2022

@author: AbelRamos
"""

datos=100
nativa=1
if datos==nativa:
    print("Los VLAN son iguales")
else:
    print("Las VLAN son diferentes")