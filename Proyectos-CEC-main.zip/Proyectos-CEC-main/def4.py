# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 01:53:40 2022

@author: AbelRamos
"""

def resta(a,b):
    print(a-b)
    
resta(5,3)
resta(3,5)
resta(a=5,b=3)
resta(b=3,a=5)
resta(5,b=3)