# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 03:58:47 2022

@author: AbelRamos
"""
d=str()
a=int()
b=bool()
c=float()
str1="Cisco"
str2="Networking"
str3="Academy"
space=" "
print(str1+str2+str3)
print("\n")
print(str1+space+str2+space+str3)
print("\n")
x=3
print("El valor de X es:"+str(x))
print(type(x))
x=str(x)