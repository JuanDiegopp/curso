# -*- coding: utf-8 -*-
"""
Created on Sun Mar 20 16:44:43 2022

@author: AbelRamos
"""

Nombre=input("Escriba su nombre:")
Apellido=input("Escriba su apellido:")
Edad=input("Escriba su edad:")
Ciudad=input("Ingrese su ciudad:")

print("¡Hola!", Nombre, Apellido, "hoy cumples", Edad,"años, felicidades", "tu pedido esta listo y entregado en la ciudad de",Ciudad, )